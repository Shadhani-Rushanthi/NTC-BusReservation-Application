export const userRoles ={
    Admin: 1,
    BusOperator: 2,
    Commutor: 3
}

export const busOperatorStatus = {
    Pending: 1,
    Approved: 2,
    Rejected: 3,
    Removed: 4
}

export const busCondition = {
    Luxury: 1,
    SemiLuxury:2
}

export const runningBusStatus = {
    sheduled: 1,
    Completed: 2,
    Canceled: 3,
    Replaced: 4
}

export const busStructure = {
    twoBYtwo: 1,
    oneBYthree: 2
}

export const passengerBusStatus = {
    confirmed: 1,
    paied: 2,
    canceled:3
}